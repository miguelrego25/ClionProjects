/**
 * @file É o ficheiro que contem a head do ficheiro logicabin.c
 *
 */

void logicabin (char *token, SPointer s);
