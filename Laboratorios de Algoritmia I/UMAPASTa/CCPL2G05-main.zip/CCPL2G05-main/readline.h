/**
 * @file É o ficheiro que contem a head do ficheiro readline.c
 *
 */

void readline (char *token, SPointer s);
