# CCPL2G05
lccLaboratorioAlg

Guião 1 ✓

Guião 2 ✓

Guião 3 ✓

Guião 4 ✓
