/**
 * @file É o ficheiro que contem a head do ficheiro array.c
 *
 */
void funarray (char *token,  SPointer s);
