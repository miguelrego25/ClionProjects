/**
 * @file É o ficheiro que contem a head do ficheiro manipstack.c
 *
 */

void manipstack (char *token, SPointer s);
