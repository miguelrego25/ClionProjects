/**
 * @file É o ficheiro que contem a head do ficheiro logica.c
 *
 */
void logica (char *token, SPointer s);
